import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth/session';
import { sanitizeCmsHtml } from '@/lib/cms/sanitize';
import pool from '@/lib/db';

type RouteContext = { params: Promise<{ slug: string }> };

export async function GET(_req: NextRequest, { params }: RouteContext) {
  const { slug } = await params;
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT a.slug, a.title, a.excerpt, a.body->>'html' AS body, a.image, a.status,
              a.meta_title, a.meta_description, a.created_at, a.updated_at,
              COALESCE(a.category, '{}') AS categories,
              cu.name AS created_by_name, uu.name AS updated_by_name
         FROM cms_articles a
         LEFT JOIN cms_users cu ON cu.id = a.created_by
         LEFT JOIN cms_users uu ON uu.id = a.updated_by
        WHERE a.slug = $1`,
      [slug]
    );
    if (!res.rows[0]) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }
    return NextResponse.json(res.rows[0]);
  } catch (err) {
    console.error('[cms/article GET]', err);
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  } finally {
    client.release();
  }
}

export async function DELETE(_req: NextRequest, { params }: RouteContext) {
  const session = await getSession(_req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { slug } = await params;
  const client = await pool.connect();
  try {
    const res = await client.query(
      `DELETE FROM cms_articles WHERE slug = $1 RETURNING id`,
      [slug]
    );
    if ((res.rowCount ?? 0) === 0) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }
    return new NextResponse(null, { status: 204 });
  } catch (err) {
    console.error('[cms/article DELETE]', err);
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  } finally {
    client.release();
  }
}

export async function PATCH(req: NextRequest, { params }: RouteContext) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { slug } = await params;
  let body: { status?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const newStatus = body.status;
  if (newStatus !== 'published' && newStatus !== 'draft') {
    return NextResponse.json({ error: 'status must be "published" or "draft"' }, { status: 400 });
  }

  const client = await pool.connect();
  try {
    const res = await client.query(
      `UPDATE cms_articles
          SET status = $1, updated_by = $2, updated_at = NOW()
        WHERE slug = $3
        RETURNING status`,
      [newStatus, session.userId, slug]
    );
    if ((res.rowCount ?? 0) === 0) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true, status: res.rows[0].status });
  } catch (err) {
    console.error('[cms/article PATCH]', err);
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  } finally {
    client.release();
  }
}

export async function PUT(req: NextRequest, { params }: RouteContext) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { slug } = await params;
  let body: {
    title?: string;
    excerpt?: string;
    body?: string;
    image?: string;
    status?: string;
    metaTitle?: string | null;
    metaDescription?: string | null;
    categories?: string[];
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const client = await pool.connect();
  try {
    const res = await client.query(
      `UPDATE cms_articles SET
         title            = COALESCE($1, title),
         excerpt          = COALESCE($2, excerpt),
         body             = COALESCE($3, body),
         image            = COALESCE($4, image),
         status           = COALESCE($5, status),
         meta_title       = $6,
         meta_description = $7,
         category         = COALESCE($8, category),
         updated_by       = $9,
         updated_at       = NOW()
       WHERE slug = $10
       RETURNING id`,
      [
        body.title ?? null,
        body.excerpt ?? null,
        body.body != null ? JSON.stringify({ html: sanitizeCmsHtml(body.body) }) : null,
        body.image ?? null,
        body.status ?? null,
        body.metaTitle ?? null,
        body.metaDescription ?? null,
        body.categories ?? null,
        session.userId,
        slug,
      ]
    );
    if ((res.rowCount ?? 0) === 0) {
      return NextResponse.json({ error: 'Article not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('[cms/article PUT]', err);
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  } finally {
    client.release();
  }
}
